package com.danimeana.eiibus.persistence;

import com.danimeana.eiibus.model.Bus;

public interface BusDataService {

	public Bus save(Bus bus);
}
