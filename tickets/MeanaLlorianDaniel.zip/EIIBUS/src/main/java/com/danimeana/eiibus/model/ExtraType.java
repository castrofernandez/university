package com.danimeana.eiibus.model;

public enum ExtraType {
	BIKE, PET, INSURANCE
}
