package com.danimeana.eiibus.model;

public enum ReserveType {
	ONEWAY, RETURN, OPENRETURN
}
