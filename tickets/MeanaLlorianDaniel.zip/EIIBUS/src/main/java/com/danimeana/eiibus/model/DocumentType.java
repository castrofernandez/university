package com.danimeana.eiibus.model;

public enum DocumentType {
	DNI, NIE, PASSPORT
}
