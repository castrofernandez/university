package com.danimeana.eiibus.model;

public enum ScheduleDay {
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}
