package com.danimeana.eiibus.business;

import com.danimeana.eiibus.model.Bus;

public interface BusManagerService {

	public Bus saveBus(Bus bus);

}
