var circo = new Object();
circo.juegos = new Object();
circo.intermedios = new Object();
circo.intermedios.util = new Object();