circo.audio = new Object();

circo.audio.acrobatas = new Audio("audio/acrobatas.mp3");
circo.audio.pato = new Audio("audio/pato.mp3");
circo.audio.mal = new Audio("audio/mal.mp3");
circo.audio.pop = new Audio("audio/pop.mp3");
circo.audio.casino = new Audio("audio/casino.mp3");
circo.audio.circo = new Audio("audio/circo.aac");
circo.audio.trompeta = new Audio("audio/trompeta.mp3");
circo.audio.matasuegras = new Audio("audio/matasuegras2.mp3");